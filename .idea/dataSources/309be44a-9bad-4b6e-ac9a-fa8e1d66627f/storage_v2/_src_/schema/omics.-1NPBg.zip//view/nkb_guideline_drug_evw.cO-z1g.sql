create definer = root@localhost view nkb_guideline_drug_evw as
select `a`.`record_id`                     AS `record_id`,
       1                                   AS `lang`,
       `a`.`drug_id`                       AS `drug_id`,
       `b`.`drug_name_chinese`             AS `drug_name`,
       `c`.`guideline_type`                AS `guideline_type`,
       `c`.`guideline_title`               AS `guideline_title`,
       `a`.`disease_id`                    AS `disease_id`,
       `d`.`disease_name_chinese`          AS `disease_name`,
       `a`.`guildeline_version`            AS `guildeline_version`,
       `a`.`gene_test_required`            AS `gene_test_required`,
       `a`.`guideline_description_chinese` AS `guideline_description`,
       `a`.`update_date`                   AS `update_date`
from (((`nkb`.`guideline_drug` `a` join `nkb`.`drug` `b`
        on ((`b`.`drug_id` = `a`.`drug_id`))) join `nkb`.`guideline` `c`
       on ((`c`.`guideline_id` = `a`.`guideline_id`))) left join `nkb`.`disease` `d`
      on ((`d`.`do_id` = `a`.`disease_id`)))
where (`a`.`checking_status_id` = 2)
union
select `a`.`record_id`             AS `record_id`,
       2                           AS `lang`,
       `a`.`drug_id`               AS `drug_id`,
       `b`.`drug_name`             AS `drug_name`,
       `c`.`guideline_type`        AS `guideline_type`,
       `c`.`guideline_title`       AS `guideline_title`,
       `a`.`disease_id`            AS `disease_id`,
       `d`.`disease_name`          AS `disease_name`,
       `a`.`guildeline_version`    AS `guildeline_version`,
       `a`.`gene_test_required`    AS `gene_test_required`,
       `a`.`guideline_description` AS `guideline_description`,
       `a`.`update_date`           AS `update_date`
from (((`nkb`.`guideline_drug` `a` join `nkb`.`drug` `b`
        on ((`b`.`drug_id` = `a`.`drug_id`))) join `nkb`.`guideline` `c`
       on ((`c`.`guideline_id` = `a`.`guideline_id`))) left join `nkb`.`disease` `d`
      on ((`d`.`do_id` = `a`.`disease_id`)))
where (`a`.`checking_status_id` = 2);

