create definer = root@localhost view variant_treatment_annotation_vw as
select distinct `a`.`annotation_id`            AS `annotation_id`,
                `a`.`gene_variant_id`          AS `gene_variant_id`,
                `gv`.`gene_id`                 AS `gene_id`,
                `gg`.`gene_symbol`             AS `gene_symbol`,
                `gv`.`gene_variant`            AS `gene_variant`,
                `gd`.`description_chinese`     AS `variant_desc`,
                'direct'                       AS `annotation_type`,
                NULL                           AS `parent_variant_id`,
                `a`.`drug_id`                  AS `drug_id`,
                `b`.`drug_name_chinese`        AS `drug_name_chinese`,
                `ad`.`disease_id`              AS `approved_disease_id`,
                `dd`.`disease_name_chinese`    AS `approved_indication`,
                `a`.`disease_id`               AS `disease_id`,
                `d`.`disease_name_chinese`     AS `disease_name_chinese`,
                `a`.`relationship_id`          AS `relationship_id`,
                `c`.`category`                 AS `relationship_category`,
                `c`.`category_chinese`         AS `relationship_category_chinese`,
                `c`.`relationship_chinese`     AS `relationship_chinese`,
                `a`.`annotation_chinese`       AS `annotation_chinese`,
                `a`.`evidence_type_id`         AS `evidence_type_id`,
                `f`.`evidence_type`            AS `evidence_type`,
                `a`.`evidence_phase_id`        AS `evidence_phase_id`,
                `g`.`evidence_phase`           AS `evidence_phase`,
                `g`.`evidence_phase_chinese`   AS `evidence_phase_chinese`,
                `a`.`evidence_ranking_id`      AS `evidence_ranking_id`,
                `h`.`evidence_ranking`         AS `evidence_ranking`,
                `h`.`evidence_ranking_chinese` AS `evidence_ranking_chinese`,
                `a`.`standard_export`          AS `standard_export`,
                `a`.`professional_export`      AS `professional_export`,
                `a`.`checking_status_id`       AS `checking_status_id`,
                `k`.`checking_status`          AS `checking_status`
from ((((((((((((`nkb`.`variant_drug_annotation` `a` join `nkb`.`gene_variant` `gv`
                 on ((`a`.`gene_variant_id` = `gv`.`gene_variant_id`))) left join `nkb`.`gene_variant_description` `gd`
                on (((`gv`.`gene_variant_id` = `gd`.`gene_variant_id`) and
                     (`gd`.`annotation_type` = 'onco')))) join `nkb`.`ncbi_gene` `gg`
               on ((`gv`.`gene_id` = `gg`.`gene_id`))) join `nkb`.`checking_status` `k`
              on ((`a`.`checking_status_id` = `k`.`status_id`))) left join `nkb`.`drug_name_vw` `b`
             on ((`b`.`drug_id` = `a`.`drug_id`))) left join `nkb`.`approved_drug` `ad`
            on (((`a`.`drug_id` = `ad`.`drug_id`) and (`ad`.`checking_status_id` <> 3)))) left join `nkb`.`disease` `dd`
           on ((`dd`.`do_id` = `ad`.`disease_id`))) left join `nkb`.`relationship` `c`
          on ((`c`.`relationship_id` = `a`.`relationship_id`))) left join `nkb`.`disease` `d`
         on ((`d`.`do_id` = `a`.`disease_id`))) left join `nkb`.`evidence_type` `f`
        on ((`f`.`evidence_type_id` = `a`.`evidence_type_id`))) left join `nkb`.`evidence_phase` `g`
       on ((`g`.`evidence_phase_id` = `a`.`evidence_phase_id`))) left join `nkb`.`evidence_ranking` `h`
      on ((`h`.`evidence_ranking_id` = `a`.`evidence_ranking_id`)))
where ((`a`.`evidence_type_id` = 2) and (`a`.`checking_status_id` = 2))
union
select distinct `a`.`annotation_id`            AS `annotation_id`,
                `p`.`gene_variant_id`          AS `gene_variant_id`,
                `gv`.`gene_id`                 AS `gene_id`,
                `gg`.`gene_symbol`             AS `gene_symbol`,
                `gv`.`gene_variant`            AS `gene_variant`,
                `gd`.`description_chinese`     AS `variant_desc`,
                'parent'                       AS `annotation_type`,
                `p`.`parent_variant_id`        AS `parent_variant_id`,
                `a`.`drug_id`                  AS `drug_id`,
                `b`.`drug_name_chinese`        AS `drug_name_chinese`,
                `ad`.`disease_id`              AS `approved_disease_id`,
                `dd`.`disease_name_chinese`    AS `approved_indication`,
                `a`.`disease_id`               AS `disease_id`,
                `d`.`disease_name_chinese`     AS `disease_name_chinese`,
                `a`.`relationship_id`          AS `relationship_id`,
                `c`.`category`                 AS `relationship_category`,
                `c`.`category_chinese`         AS `relationship_category_chinese`,
                `c`.`relationship_chinese`     AS `relationship_chinese`,
                `a`.`annotation_chinese`       AS `annotation_chinese`,
                `a`.`evidence_type_id`         AS `evidence_type_id`,
                `f`.`evidence_type`            AS `evidence_type`,
                `a`.`evidence_phase_id`        AS `evidence_phase_id`,
                `g`.`evidence_phase`           AS `evidence_phase`,
                `g`.`evidence_phase_chinese`   AS `evidence_phase_chinese`,
                `a`.`evidence_ranking_id`      AS `evidence_ranking_id`,
                `h`.`evidence_ranking`         AS `evidence_ranking`,
                `h`.`evidence_ranking_chinese` AS `evidence_ranking_chinese`,
                `a`.`standard_export`          AS `standard_export`,
                `a`.`professional_export`      AS `professional_export`,
                `a`.`checking_status_id`       AS `checking_status_id`,
                `k`.`checking_status`          AS `checking_status`
from (((((((((((((`nkb`.`gene_variant_parent` `p` join `nkb`.`variant_drug_annotation` `a`
                  on ((`p`.`parent_variant_id` = `a`.`gene_variant_id`))) join `nkb`.`gene_variant` `gv`
                 on ((`p`.`gene_variant_id` = `gv`.`gene_variant_id`))) left join `nkb`.`gene_variant_description` `gd`
                on (((`p`.`gene_variant_id` = `gd`.`gene_variant_id`) and
                     (`gd`.`annotation_type` = 'onco')))) join `nkb`.`ncbi_gene` `gg`
               on ((`gv`.`gene_id` = `gg`.`gene_id`))) join `nkb`.`checking_status` `k`
              on ((`a`.`checking_status_id` = `k`.`status_id`))) left join `nkb`.`drug_name_vw` `b`
             on ((`b`.`drug_id` = `a`.`drug_id`))) left join `nkb`.`approved_drug` `ad`
            on (((`a`.`drug_id` = `ad`.`drug_id`) and (`ad`.`checking_status_id` <> 3)))) left join `nkb`.`disease` `dd`
           on ((`dd`.`do_id` = `ad`.`disease_id`))) left join `nkb`.`relationship` `c`
          on ((`c`.`relationship_id` = `a`.`relationship_id`))) left join `nkb`.`disease` `d`
         on ((`d`.`do_id` = `a`.`disease_id`))) left join `nkb`.`evidence_type` `f`
        on ((`f`.`evidence_type_id` = `a`.`evidence_type_id`))) left join `nkb`.`evidence_phase` `g`
       on ((`g`.`evidence_phase_id` = `a`.`evidence_phase_id`))) left join `nkb`.`evidence_ranking` `h`
      on ((`h`.`evidence_ranking_id` = `a`.`evidence_ranking_id`)))
where ((`a`.`evidence_type_id` = 2) and (`a`.`checking_status_id` = 2));

