create definer = root@localhost view ngs_summary_result_vw as
select distinct `a`.`file_id`                     AS `file_id`,
                `a`.`platform`                    AS `platform`,
                `a`.`product_name`                AS `product_name`,
                `a`.`analysis_date`               AS `analysis_date`,
                `a`.`subbarcode`                  AS `subbarcode`,
                `a`.`report_id`                   AS `report_id`,
                `a`.`primary_cancer_id`           AS `primary_cancer_id`,
                `a`.`gene`                        AS `gene`,
                `a`.`variant`                     AS `variant`,
                `a`.`ori_variant`                 AS `ori_variant`,
                `a`.`mutFreq`                     AS `mutFreq`,
                `a`.`mapped_variant_id`           AS `mapped_variant_id`,
                `a`.`mapped_variant`              AS `mapped_variant`,
                `b`.`approved_this_cancer_drugs`  AS `approved_this_cancer_drugs`,
                `c`.`approved_other_cancer_drugs` AS `approved_other_cancer_drugs`,
                `d`.`clinical_trial_cancer_drugs` AS `clinical_trial_cancer_drugs`,
                `e`.`resistant_cancer_drugs`      AS `resistant_cancer_drugs`
from ((((`omics`.`this_genetic_marker_vw` `a` left join `omics`.`nkb_sensitive_this_drugs_vw` `b`
         on (((`a`.`mapped_variant_id` = `b`.`gene_variant_id`) and
              (`a`.`primary_cancer_id` = `b`.`approved_disease_id`)))) left join `omics`.`nkb_sensitive_other_drugs_vw` `c`
        on (((`a`.`mapped_variant_id` = `c`.`gene_variant_id`) and
             (`a`.`primary_cancer_id` = `c`.`approved_disease_id`)))) left join `omics`.`nkb_sensitive_trial_drugs_vw` `d`
       on ((`a`.`mapped_variant_id` = `d`.`gene_variant_id`))) left join `omics`.`nkb_resistant_cancer_drugs_vw` `e`
      on ((`a`.`mapped_variant_id` = `e`.`gene_variant_id`)));

