create definer = root@localhost view this_genetic_marker_vw as
select `a`.`file_id`            AS `file_id`,
       `r`.`report_id`          AS `report_id`,
       `a`.`platform`           AS `platform`,
       `a`.`product_name`       AS `product_name`,
       `a`.`analysis_date`      AS `analysis_date`,
       `a`.`subbarcode`         AS `subbarcode`,
       `r`.`primary_cancer_id`  AS `primary_cancer_id`,
       `a`.`gene`               AS `gene`,
       `a`.`variant`            AS `variant`,
       `a`.`ori_variant`        AS `ori_variant`,
       `pg`.`mutation_type`     AS `mutation_type`,
       `a`.`mutFreq`            AS `mutFreq`,
       `a`.`mutation_result`    AS `mutation_result`,
       `a`.`report`             AS `report`,
       `a`.`filtered_rationale` AS `filtered_rationale`,
       `a`.`mapped_variant_id`  AS `mapped_variant_id`,
       `a`.`mapped_variant`     AS `mapped_variant`,
       `a`.`exon`               AS `exon`,
       `a`.`codon`              AS `codon`
from ((`omics`.`genetic_marker_vw` `a` join `omics`.`analysis_report` `r`
       on (((`a`.`subbarcode` = `r`.`subbarcode`) and (`a`.`platform` = `r`.`platform`) and
            (`a`.`product_name` = `r`.`product_name`) and
            (`a`.`analysis_date` = `r`.`analysis_date`)))) join `omics`.`panel_gene` `pg`
      on (((`r`.`product_id` = `pg`.`product_id`) and (`a`.`gene` = `pg`.`gene_symbol`) and
           (`pg`.`category` = 'targeted'))));

