create definer = novo@`%` view nkb_disease_parent_evw as
select `a`.`do_id`                AS `do_id`,
       `a`.`disease_name`         AS `disease_name`,
       `a`.`disease_name_chinese` AS `disease_name_chinese`,
       `a`.`disease_description`  AS `disease_description`,
       `b`.`is_a`                 AS `parent_do_id`,
       `c`.`disease_name`         AS `parent_disease_name`,
       `c`.`disease_name_chinese` AS `parent_disease_chinese`
from ((`nkb`.`disease_ontology` `a` join `nkb`.`disease_hierarchy` `b`
       on ((`a`.`do_id` = `b`.`do_id`))) join `nkb`.`disease_ontology` `c` on ((`c`.`do_id` = `b`.`is_a`)));

-- comment on column nkb_disease_parent_evw.do_id not supported: DOID - primary key of disease ontology

-- comment on column nkb_disease_parent_evw.disease_description not supported: definition

