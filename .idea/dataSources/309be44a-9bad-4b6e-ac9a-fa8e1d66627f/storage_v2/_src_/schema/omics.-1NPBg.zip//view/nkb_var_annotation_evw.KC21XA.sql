create definer = novo@`%` view nkb_var_annotation_evw as
select `a`.`annotation_id`       AS `annotation_id`,
       2                         AS `lang`,
       `a`.`var_id`              AS `var_id`,
       `b`.`gene_symbol`         AS `gene_symbol`,
       `v`.`gene_variant`        AS `gene_variant`,
       `a`.`do_id`               AS `do_id`,
       `c`.`disease_name`        AS `disease_name`,
       `a`.`drug_annotation`     AS `drug_annotation`,
       `a`.`clinical_annotation` AS `clinical_annotation`,
       `s`.`checking_status`     AS `checking_status`,
       `a`.`update_date`         AS `update_date`
from ((((`nkb`.`variant_annotation` `a` join `nkb`.`gene_variant` `v`
         on ((`v`.`gene_variant_id` = `a`.`var_id`))) join `nkb`.`ncbi_gene` `b`
        on ((`v`.`gene_id` = `b`.`gene_id`))) join `nkb`.`disease` `c`
       on ((`a`.`do_id` = `c`.`do_id`))) join `nkb`.`checking_status` `s`
      on ((`a`.`checking_status_id` = `s`.`status_id`)))
union
select `a`.`annotation_id`               AS `annotation_id`,
       1                                 AS `lang`,
       `a`.`var_id`                      AS `var_id`,
       `b`.`gene_symbol`                 AS `gene_symbol`,
       `v`.`gene_variant`                AS `gene_variant`,
       `a`.`do_id`                       AS `do_id`,
       `c`.`disease_name_chinese`        AS `disease_name`,
       `a`.`drug_annotation_chinese`     AS `drug_annotation`,
       `a`.`clinical_annotation_chinese` AS `clinical_annotation`,
       `s`.`checking_status`             AS `checking_status`,
       `a`.`update_date`                 AS `update_date`
from ((((`nkb`.`variant_annotation` `a` join `nkb`.`gene_variant` `v`
         on ((`v`.`gene_variant_id` = `a`.`var_id`))) join `nkb`.`ncbi_gene` `b`
        on ((`v`.`gene_id` = `b`.`gene_id`))) join `nkb`.`disease` `c`
       on ((`a`.`do_id` = `c`.`do_id`))) join `nkb`.`checking_status` `s`
      on ((`a`.`checking_status_id` = `s`.`status_id`)));

