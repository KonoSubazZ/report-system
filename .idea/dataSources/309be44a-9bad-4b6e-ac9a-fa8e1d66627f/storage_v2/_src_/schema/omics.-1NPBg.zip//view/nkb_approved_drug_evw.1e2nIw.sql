create definer = novo@`%` view nkb_approved_drug_evw as
select `t1`.`drug_id`                                    AS `drug_id`,
       `t1`.`drug_name`                                  AS `drug_name`,
       `t1`.`lang`                                       AS `lang`,
       ifnull(`t1`.`disease_id`, 0)                      AS `disease_id`,
       ifnull(`t2`.`approved`, 0)                        AS `approved`,
       ifnull(`t2`.`CFDA`, 0)                            AS `CFDA`,
       `t1`.`drug_approval_description`                  AS `drug_approval_description`,
       ifnull(`t1`.`update_date`, '1970-01-01 00:00:00') AS `update_date`
from (((select `b`.`drug_id`              AS `drug_id`,
               `b`.`drug_name`            AS `drug_name`,
               2                          AS `lang`,
               `a`.`disease_id`           AS `disease_id`,
               `a`.`approval_description` AS `drug_approval_description`,
               `a`.`update_date`          AS `update_date`
        from (`nkb`.`drug` `b` left join `nkb`.`approved_drug` `a`
              on (((`a`.`drug_id` = `b`.`drug_id`) and (`a`.`checking_status_id` = 2))))
        where (`b`.`checking_status_id` <> 3))
       union
       select `b`.`drug_id`                      AS `drug_id`,
              `b`.`drug_name_chinese`            AS `drug_name`,
              1                                  AS `lang`,
              `a`.`disease_id`                   AS `disease_id`,
              `a`.`approval_description_chinese` AS `drug_approval_description`,
              `a`.`update_date`                  AS `update_date`
       from (`nkb`.`drug` `b` left join `nkb`.`approved_drug` `a`
             on (((`a`.`drug_id` = `b`.`drug_id`) and (`a`.`checking_status_id` = 2))))
       where (`b`.`checking_status_id` <> 3)) `t1` left join (select `nkb`.`approved_drug`.`drug_id`                                    AS `drug_id`,
                                                                     if((count(distinct `nkb`.`approved_drug`.`disease_id`) > 0), 1, 0) AS `approved`,
                                                                     if((sum(if(
                                                                             (locate('NMPA', `nkb`.`approved_drug`.`approving_agency`) > 0),
                                                                             1, 0)) > 0), 1,
                                                                        0)                                                              AS `CFDA`
                                                              from `nkb`.`approved_drug`
                                                              where (`nkb`.`approved_drug`.`checking_status_id` = 2)
                                                              group by `nkb`.`approved_drug`.`drug_id`) `t2`
      on ((`t1`.`drug_id` = `t2`.`drug_id`)));

