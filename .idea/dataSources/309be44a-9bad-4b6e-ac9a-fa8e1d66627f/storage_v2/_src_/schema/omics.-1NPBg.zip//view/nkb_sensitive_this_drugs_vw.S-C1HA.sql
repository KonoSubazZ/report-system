create definer = root@localhost view nkb_sensitive_this_drugs_vw as
select `a`.`gene_variant_id`                                        AS `gene_variant_id`,
       `a`.`approved_disease_id`                                    AS `approved_disease_id`,
       `a`.`approved_indication`                                    AS `approved_indication`,
       group_concat(distinct `a`.`drug_name_chinese` separator ',') AS `approved_this_cancer_drugs`
from `omics`.`nkb_variant_treatment_annotation` `a`
where ((`a`.`relationship_category` = 'Sensitive') and (`a`.`approved_disease_id` is not null))
group by `a`.`gene_variant_id`, `a`.`approved_disease_id`, `a`.`approved_indication`;

