create definer = root@localhost view pdl1_result_vw as
select `a`.`result_id`                AS `result_id`,
       `a`.`report_id`                AS `report_id`,
       `b`.`sample_id`                AS `sample_id`,
       `c`.`barcode`                  AS `barcode`,
       `c`.`subbarcode`               AS `subbarcode`,
       `c`.`disease_type`             AS `disease_type`,
       `b`.`test_id`                  AS `test_id`,
       `d`.`category`                 AS `category`,
       `d`.`test_name`                AS `test_name`,
       `a`.`tumor_expression_result`  AS `tumor_expression_result`,
       `a`.`tumor_expression_pct`     AS `tumor_expression_pct`,
       `a`.`immuno_expression_result` AS `immuno_expression_result`,
       `a`.`immuno_expression_pct`    AS `immuno_expression_pct`,
       `a`.`tumor_cell_dying`         AS `tumor_cell_dying`,
       `a`.`immuno_cell_dying`        AS `immuno_cell_dying`,
       `a`.`pdl1_scope_description`   AS `pdl1_scope_description`,
       `a`.`purity_scope_description` AS `purity_scope_description`,
       `b`.`tested_date`              AS `tested_date`,
       `b`.`tested_by`                AS `tested_by`,
       `b`.`checked_date`             AS `checked_date`,
       `b`.`checked_by`               AS `checked_by`,
       `b`.`report_date`              AS `report_date`
from (((`omics`.`pdl1_result` `a` join `omics`.`report` `b`
        on ((`b`.`report_id` = `a`.`report_id`))) join `omics`.`sample_file` `c`
       on ((`c`.`sample_id` = `b`.`sample_id`))) join `omics`.`genetic_test` `d` on ((`d`.`test_id` = `b`.`test_id`)));

-- comment on column pdl1_result_vw.disease_type not supported: 临床诊断

-- comment on column pdl1_result_vw.tumor_expression_result not supported: 有表达 / 无表达

-- comment on column pdl1_result_vw.tumor_expression_pct not supported: %

-- comment on column pdl1_result_vw.immuno_expression_result not supported: 有表达 / 无表达

-- comment on column pdl1_result_vw.immuno_expression_pct not supported: %

