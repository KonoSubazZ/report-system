create definer = root@localhost view nkb_sensitive_drugs_vw as
select `omics`.`nkb_variant_treatment_annotation`.`annotation_id`                 AS `annotation_id`,
       `omics`.`nkb_variant_treatment_annotation`.`gene_variant_id`               AS `gene_variant_id`,
       `omics`.`nkb_variant_treatment_annotation`.`gene_id`                       AS `gene_id`,
       `omics`.`nkb_variant_treatment_annotation`.`gene_symbol`                   AS `gene_symbol`,
       `omics`.`nkb_variant_treatment_annotation`.`gene_variant`                  AS `gene_variant`,
       `omics`.`nkb_variant_treatment_annotation`.`annotation_type`               AS `annotation_type`,
       `omics`.`nkb_variant_treatment_annotation`.`drug_id`                       AS `drug_id`,
       `omics`.`nkb_variant_treatment_annotation`.`drug_name_chinese`             AS `drug_name_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`approved_disease_id`           AS `approved_disease_id`,
       `omics`.`nkb_variant_treatment_annotation`.`approved_indication`           AS `approved_indication`,
       `omics`.`nkb_variant_treatment_annotation`.`disease_id`                    AS `disease_id`,
       `omics`.`nkb_variant_treatment_annotation`.`disease_name_chinese`          AS `disease_name_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`relationship_id`               AS `relationship_id`,
       `omics`.`nkb_variant_treatment_annotation`.`relationship_category`         AS `relationship_category`,
       `omics`.`nkb_variant_treatment_annotation`.`relationship_category_chinese` AS `relationship_category_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`relationship_chinese`          AS `relationship_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`annotation_chinese`            AS `annotation_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_type_id`              AS `evidence_type_id`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_type`                 AS `evidence_type`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_phase_id`             AS `evidence_phase_id`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_phase`                AS `evidence_phase`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_phase_chinese`        AS `evidence_phase_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_ranking_id`           AS `evidence_ranking_id`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_ranking`              AS `evidence_ranking`,
       `omics`.`nkb_variant_treatment_annotation`.`evidence_ranking_chinese`      AS `evidence_ranking_chinese`,
       `omics`.`nkb_variant_treatment_annotation`.`standard_export`               AS `standard_export`,
       `omics`.`nkb_variant_treatment_annotation`.`professional_export`           AS `professional_export`,
       `omics`.`nkb_variant_treatment_annotation`.`checking_status_id`            AS `checking_status_id`,
       `omics`.`nkb_variant_treatment_annotation`.`checking_status`               AS `checking_status`
from `omics`.`nkb_variant_treatment_annotation`
where ((`omics`.`nkb_variant_treatment_annotation`.`relationship_category` = 'Sensitive') and
       (`omics`.`nkb_variant_treatment_annotation`.`approved_disease_id` is not null));

