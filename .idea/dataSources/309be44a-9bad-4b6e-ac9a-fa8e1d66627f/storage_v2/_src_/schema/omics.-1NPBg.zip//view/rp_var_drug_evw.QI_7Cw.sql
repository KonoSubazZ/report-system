create definer = novo@`%` view rp_var_drug_evw as
select `a`.`record_id`            AS `record_id`,
       `a`.`lang`                 AS `lang`,
       `a`.`gene`                 AS `gene`,
       `a`.`variant`              AS `variant`,
       `a`.`ori_variant`          AS `ori_variant`,
       `a`.`disease_id`           AS `disease_id`,
       `b`.`disease_name_chinese` AS `disease_name_chinese`,
       `a`.`var_drug_desc`        AS `var_drug_desc`,
       `a`.`drugsA`               AS `drugsA`,
       `a`.`drugsB`               AS `drugsB`,
       `a`.`drugsC`               AS `drugsC`,
       `a`.`drugsD`               AS `drugsD`,
       `a`.`resistant_drugs`      AS `resistant_drugs`,
       `a`.`clinical_trial`       AS `clinical_trial`,
       `a`.`modified`             AS `modified`,
       `a`.`update_by`            AS `update_by`,
       `a`.`update_date`          AS `update_date`,
       `a`.`check_date`           AS `check_date`
from (`omics`.`rp_var_drug` `a` join `nkb`.`disease` `b` on ((`a`.`disease_id` = `b`.`do_id`)));

