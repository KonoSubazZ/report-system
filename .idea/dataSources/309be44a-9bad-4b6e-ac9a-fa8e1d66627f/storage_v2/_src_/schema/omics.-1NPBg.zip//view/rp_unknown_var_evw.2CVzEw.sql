create definer = novo@`%` view rp_unknown_var_evw as
select `a`.`record_id`            AS `record_id`,
       `a`.`lang`                 AS `lang`,
       `a`.`gene`                 AS `gene`,
       `a`.`variant`              AS `variant`,
       `a`.`ori_variant`          AS `ori_variant`,
       `a`.`disease_id`           AS `disease_id`,
       `b`.`disease_name_chinese` AS `disease_name_chinese`,
       `a`.`result_type`          AS `result_type`,
       `a`.`gene_description`     AS `gene_description`,
       `a`.`var_drug_desc`        AS `var_drug_desc`,
       `a`.`modified`             AS `modified`,
       `a`.`update_by`            AS `update_by`,
       `a`.`update_date`          AS `update_date`,
       `a`.`check_date`           AS `check_date`
from (`omics`.`rp_unknown_var` `a` join `nkb`.`disease` `b` on ((`a`.`disease_id` = `b`.`do_id`)));

