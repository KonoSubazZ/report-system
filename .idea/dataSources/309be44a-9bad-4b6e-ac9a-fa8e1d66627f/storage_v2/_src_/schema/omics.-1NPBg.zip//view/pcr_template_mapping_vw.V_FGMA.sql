create definer = root@localhost view pcr_template_mapping_vw as
select `a`.`mapping_id`    AS `mapping_id`,
       `a`.`test_id`       AS `test_id`,
       `b`.`category`      AS `category`,
       `b`.`test_name`     AS `test_name`,
       `a`.`result`        AS `result`,
       `a`.`template_id`   AS `template_id`,
       `c`.`template_name` AS `template_name`,
       `c`.`path`          AS `path`
from ((`omics`.`pcr_template_mapping` `a` join `omics`.`genetic_test` `b`
       on ((`b`.`test_id` = `a`.`test_id`))) join `omics`.`pcr_template` `c`
      on ((`c`.`template_id` = `a`.`template_id`)));

