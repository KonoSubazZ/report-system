create definer = root@localhost view nkb_gene_annotation_evw as
select `a`.`annotation_id`       AS `annotation_id`,
       2                         AS `lang`,
       `b`.`gene_symbol`         AS `gene_symbol`,
       `a`.`do_id`               AS `do_id`,
       `c`.`disease_name`        AS `disease_name`,
       `a`.`drug_annotation`     AS `drug_annotation`,
       `a`.`clinical_annotation` AS `clinical_annotation`,
       `s`.`checking_status`     AS `checking_status`,
       `a`.`update_date`         AS `update_date`
from (((`nkb`.`gene_annotation` `a` join `nkb`.`ncbi_gene` `b`
        on ((`a`.`gene_id` = `b`.`gene_id`))) join `nkb`.`disease` `c`
       on ((`a`.`do_id` = `c`.`do_id`))) join `nkb`.`checking_status` `s`
      on ((`a`.`checking_status_id` = `s`.`status_id`)))
union
select `a`.`annotation_id`               AS `annotation_id`,
       1                                 AS `lang`,
       `b`.`gene_symbol`                 AS `gene_symbol`,
       `a`.`do_id`                       AS `do_id`,
       `c`.`disease_name_chinese`        AS `disease_name`,
       `a`.`drug_annotation_chinese`     AS `drug_annotation`,
       `a`.`clinical_annotation_chinese` AS `clinical_annotation`,
       `s`.`checking_status`             AS `checking_status`,
       `a`.`update_date`                 AS `update_date`
from (((`nkb`.`gene_annotation` `a` join `nkb`.`ncbi_gene` `b`
        on ((`a`.`gene_id` = `b`.`gene_id`))) join `nkb`.`disease` `c`
       on ((`a`.`do_id` = `c`.`do_id`))) join `nkb`.`checking_status` `s`
      on ((`a`.`checking_status_id` = `s`.`status_id`)));

