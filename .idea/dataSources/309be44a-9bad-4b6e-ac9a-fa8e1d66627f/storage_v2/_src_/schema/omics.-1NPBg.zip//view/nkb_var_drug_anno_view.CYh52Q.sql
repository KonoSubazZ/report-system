create definer = novo@localhost view nkb_var_drug_anno_view as
select `a`.`annotation_id`                                                                                     AS `annotation_id`,
       1                                                                                                       AS `lang`,
       `a`.`gene_variant_id`                                                                                   AS `gene_variant_id`,
       `b`.`gene_symbol`                                                                                       AS `gene_symbol`,
       `b`.`gene_variant`                                                                                      AS `gene_variant`,
       `a`.`drug_id`                                                                                           AS `drug_id`,
       `c`.`drug_name_chinese`                                                                                 AS `drug_name`,
       if(((`a`.`has_previous_clinical_result` like 'Y') or isnull(`a`.`has_previous_clinical_result`)), 1,
          0)                                                                                                   AS `give`,
       `a`.`disease_id`                                                                                        AS `anno_disease_id`,
       `d`.`disease_name_chinese`                                                                              AS `anno_disease_name`,
       `e`.`relationship`                                                                                      AS `relationship`,
       `a`.`evidence_phase_id`                                                                                 AS `evidence_phase_id`,
       `m`.`evidence_phase_chinese`                                                                            AS `evidence_phase`,
       `a`.`mutation_type`                                                                                     AS `mutation_type`,
       `a`.`has_previous_clinical_result`                                                                      AS `has_previous_clinical_result`,
       `a`.`annotation_chinese`                                                                                AS `annotation`,
       `a`.`other_test_required`                                                                               AS `other_test_required`,
       `a`.`update_date`                                                                                       AS `update_date`
from (((((`nkb`.`variant_drug_annotation` `a` join `nkb`.`gene_variant_vw` `b`
          on ((`b`.`gene_variant_id` = `a`.`gene_variant_id`))) left join `nkb`.`drug` `c`
         on ((`c`.`drug_id` = `a`.`drug_id`))) left join `nkb`.`disease` `d`
        on (((`d`.`do_id` = `a`.`disease_id`) and (`d`.`checking_status_id` = 2)))) left join `nkb`.`relationship` `e`
       on ((`e`.`relationship_id` = `a`.`relationship_id`))) left join `nkb`.`evidence_phase` `m`
      on ((`m`.`evidence_phase_id` = `a`.`evidence_phase_id`)))
where ((`a`.`checking_status_id` = 2) and
       ((`a`.`relationship_id` = 1) or (`a`.`relationship_id` = 4) or (`a`.`relationship_id` = 6)) and
       (`a`.`evidence_phase_id` > 11) and (`a`.`evidence_type_id` = 2) and (`c`.`checking_status_id` = 2))
union
select `a`.`annotation_id`                                                                                     AS `annotation_id`,
       2                                                                                                       AS `lang`,
       `a`.`gene_variant_id`                                                                                   AS `gene_variant_id`,
       `b`.`gene_symbol`                                                                                       AS `gene_symbol`,
       `b`.`gene_variant`                                                                                      AS `gene_variant`,
       `a`.`drug_id`                                                                                           AS `drug_id`,
       `c`.`drug_name`                                                                                         AS `drug_name`,
       if(((`a`.`has_previous_clinical_result` like 'Y') or isnull(`a`.`has_previous_clinical_result`)), 1,
          0)                                                                                                   AS `give`,
       `a`.`disease_id`                                                                                        AS `anno_disease_id`,
       `d`.`disease_name`                                                                                      AS `anno_disease_name`,
       `e`.`relationship`                                                                                      AS `relationship`,
       `a`.`evidence_phase_id`                                                                                 AS `evidence_phase_id`,
       `m`.`evidence_phase`                                                                                    AS `evidence_phase`,
       `a`.`mutation_type`                                                                                     AS `mutation_type`,
       `a`.`has_previous_clinical_result`                                                                      AS `has_previous_clinical_result`,
       `a`.`annotation`                                                                                        AS `annotation`,
       `a`.`other_test_required`                                                                               AS `other_test_required`,
       `a`.`update_date`                                                                                       AS `update_date`
from (((((`nkb`.`variant_drug_annotation` `a` join `nkb`.`gene_variant_vw` `b`
          on ((`b`.`gene_variant_id` = `a`.`gene_variant_id`))) join `nkb`.`drug` `c`
         on ((`c`.`drug_id` = `a`.`drug_id`))) join `nkb`.`disease` `d`
        on (((`d`.`do_id` = `a`.`disease_id`) and (`d`.`checking_status_id` = 2)))) join `nkb`.`relationship` `e`
       on ((`e`.`relationship_id` = `a`.`relationship_id`))) join `nkb`.`evidence_phase` `m`
      on ((`m`.`evidence_phase_id` = `a`.`evidence_phase_id`)))
where ((`a`.`checking_status_id` = 2) and
       ((`a`.`relationship_id` = 1) or (`a`.`relationship_id` = 4) or (`a`.`relationship_id` = 6)) and
       (`a`.`evidence_phase_id` > 11) and (`a`.`evidence_type_id` = 2) and (`c`.`checking_status_id` = 2));

