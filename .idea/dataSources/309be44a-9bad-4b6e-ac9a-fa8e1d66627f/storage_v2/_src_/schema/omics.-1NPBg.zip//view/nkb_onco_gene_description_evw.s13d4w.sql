create definer = root@localhost view nkb_onco_gene_description_evw as
select `a`.`gene_id`                     AS `gene_id`,
       `g`.`gene_symbol`                 AS `gene_symbol`,
       1                                 AS `lang`,
       `a`.`gene_name_chinese`           AS `gene_name`,
       `a`.`gene_description_chinese`    AS `gene_description`,
       `a`.`related_pathway`             AS `related_pathway`,
       `a`.`pathway_description_chinese` AS `pathway_description`,
       `a`.`update_date`                 AS `update_date`
from (`nkb`.`gene_description` `a` join `nkb`.`ncbi_gene` `g` on ((`a`.`gene_id` = `g`.`gene_id`)))
where ((`a`.`annotation_type` = 'onco') and (`a`.`checking_status_id` = 2))
union
select `a`.`gene_id`             AS `gene_id`,
       `g`.`gene_symbol`         AS `gene_symbol`,
       2                         AS `lang`,
       `a`.`gene_name`           AS `gene_name`,
       `a`.`gene_description`    AS `gene_description`,
       `a`.`related_pathway`     AS `related_pathway`,
       `a`.`pathway_description` AS `pathway_description`,
       `a`.`update_date`         AS `update_date`
from (`nkb`.`gene_description` `a` join `nkb`.`ncbi_gene` `g` on ((`a`.`gene_id` = `g`.`gene_id`)))
where ((`a`.`annotation_type` = 'onco') and (`a`.`checking_status_id` = 2));

