create definer = root@localhost view ngs_summary_drugs_vw as
select distinct `b`.`approved_disease_id`         AS `approved_disease_id`,
                `b`.`approved_indication`         AS `approved_indication`,
                `a`.`gene_variant_id`             AS `gene_variant_id`,
                `a`.`gene_id`                     AS `gene_id`,
                `a`.`gene_symbol`                 AS `gene_symbol`,
                `a`.`gene_variant`                AS `gene_variant`,
                `b`.`approved_this_cancer_drugs`  AS `approved_this_cancer_drugs`,
                `c`.`approved_other_cancer_drugs` AS `approved_other_cancer_drugs`,
                `d`.`clinical_trial_cancer_drugs` AS `clinical_trial_cancer_drugs`,
                `e`.`resistant_cancer_drugs`      AS `resistant_cancer_drugs`
from ((((`omics`.`nkb_variant_treatment_annotation` `a` left join `omics`.`nkb_sensitive_this_drugs_vw` `b`
         on ((`a`.`gene_variant_id` = `b`.`gene_variant_id`))) left join `omics`.`nkb_sensitive_other_drugs_vw` `c`
        on (((`a`.`gene_variant_id` = `c`.`gene_variant_id`) and
             (`b`.`approved_disease_id` = `c`.`approved_disease_id`)))) left join `omics`.`nkb_sensitive_trial_drugs_vw` `d`
       on ((`a`.`gene_variant_id` = `d`.`gene_variant_id`))) left join `omics`.`nkb_resistant_cancer_drugs_vw` `e`
      on ((`a`.`gene_variant_id` = `e`.`gene_variant_id`)));

