create definer = root@localhost view pcr_result_vw as
select `a`.`result_id`         AS `result_id`,
       `a`.`report_id`         AS `report_id`,
       `b`.`sample_id`         AS `sample_id`,
       `c`.`barcode`           AS `barcode`,
       `c`.`subbarcode`        AS `subbarcode`,
       `c`.`disease_type`      AS `disease_type`,
       `b`.`test_id`           AS `test_id`,
       `c`.`specimen_type`     AS `specimen_type`,
       `c`.`clinicalremark`    AS `clinicalremark`,
       `c`.`cancertype`        AS `cancertype`,
       `c`.`pathologicaltype`  AS `pathologicaltype`,
       `c`.`clinicalstages`    AS `clinicalstages`,
       `c`.`libraryname`       AS `libraryname`,
       `c`.`doctorname`        AS `doctorname`,
       `c`.`received_date`     AS `received_date`,
       `c`.`person_name`       AS `person_name`,
       `c`.`sales_contact`     AS `sales_contact`,
       `c`.`hospital`          AS `hospital`,
       `c`.`locationname`      AS `locationname`,
       `d`.`category`          AS `category`,
       `d`.`test_name`         AS `test_name`,
       `a`.`pcr_variant_id`    AS `pcr_variant_id`,
       `e`.`gene_symbol`       AS `gene_symbol`,
       `e`.`variant`           AS `variant`,
       `a`.`variant_frequency` AS `variant_frequency`,
       `b`.`tested_date`       AS `tested_date`,
       `b`.`tested_by`         AS `tested_by`,
       `b`.`checked_date`      AS `checked_date`,
       `b`.`checked_by`        AS `checked_by`,
       `b`.`report_date`       AS `report_date`
from ((((`omics`.`pcr_result` `a` join `omics`.`report` `b`
         on ((`b`.`report_id` = `a`.`report_id`))) join `omics`.`sample_file` `c`
        on ((`c`.`sample_id` = `b`.`sample_id`))) join `omics`.`genetic_test` `d`
       on ((`d`.`test_id` = `b`.`test_id`))) join `omics`.`pcr_variant` `e`
      on ((`e`.`pcr_variant_id` = `a`.`pcr_variant_id`)));

-- comment on column pcr_result_vw.disease_type not supported: 临床诊断

-- comment on column pcr_result_vw.clinicalremark not supported: 临床备注

-- comment on column pcr_result_vw.cancertype not supported: 检测癌种

-- comment on column pcr_result_vw.variant_frequency not supported: %

