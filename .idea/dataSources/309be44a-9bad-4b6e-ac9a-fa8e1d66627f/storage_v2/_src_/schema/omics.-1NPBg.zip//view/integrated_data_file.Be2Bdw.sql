create definer = root@localhost view integrated_data_file as
select distinct `a`.`file_id`          AS `file_id`,
                `a`.`file_path`        AS `file_path`,
                `a`.`file_name`        AS `file_name`,
                `a`.`data_type`        AS `data_type`,
                `a`.`file_type`        AS `file_type`,
                `a`.`analysis_date`    AS `analysis_date`,
                `a`.`barcode`          AS `barcode`,
                `a`.`subbarcode`       AS `subbarcode`,
                `b`.`person_name`      AS `person_name`,
                `a`.`product_name`     AS `path_name`,
                `b`.`product_name`     AS `product_name`,
                `a`.`platform`         AS `platform`,
                `b`.`received_date`    AS `received_date`,
                `b`.`hospital`         AS `hospital`,
                `b`.`specimen_type`    AS `specimen_type`,
                `b`.`clinicalremark`   AS `clinicalremark`,
                `b`.`cancertype`       AS `cancertype`,
                `b`.`pathologicaltype` AS `pathologicaltype`,
                `b`.`fastcode`         AS `fastcode`
from (`omics`.`data_file_status` `a` left join `omics`.`sample_file` `b` on ((`a`.`subbarcode` = `b`.`subbarcode`)))
where ((`a`.`data_type` = 'mutation') and (`a`.`status` = 'Loaded'));

-- comment on column integrated_data_file.barcode not supported: patient id

-- comment on column integrated_data_file.subbarcode not supported: speciment id

-- comment on column integrated_data_file.clinicalremark not supported: 临床备注

-- comment on column integrated_data_file.cancertype not supported: 检测癌种

