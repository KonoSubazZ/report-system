create definer = root@localhost view nkb_sensitive_other_drugs_vw as
select `a`.`gene_variant_id`                                        AS `gene_variant_id`,
       `a`.`approved_disease_id`                                    AS `approved_disease_id`,
       `a`.`approved_indication`                                    AS `approved_indication`,
       group_concat(distinct `b`.`drug_name_chinese` separator ',') AS `approved_other_cancer_drugs`
from (`omics`.`nkb_sensitive_drugs_vw` `a` join `omics`.`nkb_sensitive_drugs_vw` `b`
      on ((`a`.`gene_variant_id` = `b`.`gene_variant_id`)))
where (not ((`b`.`gene_variant_id`, `a`.`approved_disease_id`, `b`.`drug_id`) in
            (select distinct `c`.`gene_variant_id`, `c`.`approved_disease_id`, `c`.`drug_id`
             from `omics`.`nkb_sensitive_drugs_vw` `c`
             where ((`c`.`gene_variant_id` = `a`.`gene_variant_id`) and
                    (`c`.`approved_disease_id` = `a`.`approved_disease_id`)))))
group by `a`.`gene_variant_id`, `a`.`approved_disease_id`, `a`.`approved_indication`;

