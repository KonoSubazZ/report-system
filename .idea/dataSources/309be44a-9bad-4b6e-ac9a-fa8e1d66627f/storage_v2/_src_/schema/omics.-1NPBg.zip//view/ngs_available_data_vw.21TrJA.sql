create definer = root@localhost view ngs_available_data_vw as
select distinct `b`.`report_id`                                AS `report_id`,
                `a`.`platform`                                 AS `platform`,
                `a`.`analysis_date`                            AS `analysis_date`,
                `a`.`barcode`                                  AS `barcode`,
                `a`.`subbarcode`                               AS `subbarcode`,
                ifnull(`b`.`product_name`, `a`.`product_name`) AS `product_name`,
                `c`.`disease_class_chinese`                    AS `primary_cancer`,
                `b`.`chem_cancer`                              AS `chem_cancer`,
                `b`.`analyzer`                                 AS `analyzer`,
                `b`.`checked_date`                             AS `checked_date`,
                `b`.`checked_by`                               AS `checked_by`,
                `b`.`report_date`                              AS `report_date`,
                `b`.`report_filename`                          AS `report_filename`,
                `b`.`report_file_path`                         AS `report_file_path`,
                `b`.`status`                                   AS `status`,
                `b`.`report_time`                              AS `report_time`
from ((`omics`.`data_file_status` `a` left join `omics`.`analysis_report` `b`
       on (((`b`.`subbarcode` = `a`.`subbarcode`) and (`b`.`platform` = `a`.`platform`) and
            (`b`.`analysis_date` = `a`.`analysis_date`)))) left join `omics`.`disease_class` `c`
      on ((`b`.`primary_cancer_id` = `c`.`class_id`)))
where (`a`.`subbarcode` <> '');

-- comment on column ngs_available_data_vw.barcode not supported: patient id

-- comment on column ngs_available_data_vw.subbarcode not supported: speciment id

-- comment on column ngs_available_data_vw.chem_cancer not supported: 化疗癌种

-- comment on column ngs_available_data_vw.report_time not supported: 生成报告时间

