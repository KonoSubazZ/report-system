create definer = root@localhost view genetic_marker_vw as
select `a`.`file_id`                                                                          AS `file_id`,
       `b`.`platform`                                                                         AS `platform`,
       `b`.`product_name`                                                                     AS `product_name`,
       `b`.`analysis_date`                                                                    AS `analysis_date`,
       `b`.`subbarcode`                                                                       AS `subbarcode`,
       `a`.`Gene_knownGene`                                                                   AS `gene`,
       `a`.`variant`                                                                          AS `variant`,
       `a`.`ori_variant`                                                                      AS `ori_variant`,
       `a`.`mutation_type`                                                                    AS `mutation_type`,
       `a`.`mutFreq`                                                                          AS `mutFreq`,
       `a`.`report`                                                                           AS `report`,
       `a`.`filtered_rationale`                                                               AS `filtered_rationale`,
       `a`.`mapped_variant_id`                                                                AS `mapped_variant_id`,
       `a`.`mapped_variant`                                                                   AS `mapped_variant`,
       `a`.`exon`                                                                             AS `exon`,
       `a`.`codon`                                                                            AS `codon`,
       concat(`a`.`exon`, '号外显子', `a`.`mutation_type`, '(突变丰度:', `a`.`mutFreq`, '%)') AS `mutation_result`
from (`omics`.`snp_indel_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`                                                                                 AS `file_id`,
       `b`.`platform`                                                                                AS `platform`,
       `b`.`product_name`                                                                            AS `product_name`,
       `b`.`analysis_date`                                                                           AS `analysis_date`,
       `b`.`subbarcode`                                                                              AS `subbarcode`,
       `a`.`gene`                                                                                    AS `gene`,
       'Amplification'                                                                               AS `variant`,
       'Amplification'                                                                               AS `ori_variant`,
       '拷贝数变异'                                                                                  AS `mutation_type`,
       concat(convert(format((`a`.`copy_number` / 2), 1) using utf8mb4), 'X')                        AS `mutFreq`,
       `a`.`report`                                                                                  AS `report`,
       `a`.`filtered_rationale`                                                                      AS `filtered_rationale`,
       `a`.`mapped_variant_id`                                                                       AS `mapped_variant_id`,
       `a`.`mapped_variant`                                                                          AS `mapped_variant`,
       ''                                                                                            AS `exon`,
       ''                                                                                            AS `codon`,
       concat(`a`.`gene`, '基因拷贝数变异(', convert(format(`a`.`copy_number`, 1) using utf8),
              'X)')                                                                                  AS `mutation_result`
from (`omics`.`cnv_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`                     AS `file_id`,
       `b`.`platform`                    AS `platform`,
       `b`.`product_name`                AS `product_name`,
       `b`.`analysis_date`               AS `analysis_date`,
       `b`.`subbarcode`                  AS `subbarcode`,
       `a`.`gene1`                       AS `gene`,
       `a`.`variant`                     AS `variant`,
       `a`.`ori_variant`                 AS `ori_variant`,
       '融合'                            AS `mutation_type`,
       format((100 * `a`.`freq`), 2)     AS `mutFreq`,
       `a`.`report`                      AS `report`,
       `a`.`filtered_rationale`          AS `filtered_rationale`,
       `a`.`mapped_variant_id`           AS `mapped_variant_id`,
       `a`.`mapped_variant`              AS `mapped_variant`,
       ''                                AS `exon`,
       ''                                AS `codon`,
       concat(`a`.`variant`, '融合突变') AS `mutation_result`
from (`omics`.`fusion_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`                                                                         AS `file_id`,
       `b`.`platform`                                                                        AS `platform`,
       `b`.`product_name`                                                                    AS `product_name`,
       `b`.`analysis_date`                                                                   AS `analysis_date`,
       `b`.`subbarcode`                                                                      AS `subbarcode`,
       `a`.`gene`                                                                            AS `gene`,
       `a`.`variant`                                                                         AS `variant`,
       `a`.`ori_variant`                                                                     AS `ori_variant`,
       `a`.`mutation_type`                                                                   AS `mutation_type`,
       `a`.`f_freq`                                                                          AS `mutFreq`,
       `a`.`report`                                                                          AS `report`,
       `a`.`filtered_rationale`                                                              AS `filtered_rationale`,
       `a`.`mapped_variant_id`                                                               AS `mapped_variant_id`,
       `a`.`mapped_variant`                                                                  AS `mapped_variant`,
       `a`.`exon`                                                                            AS `exon`,
       `a`.`codon`                                                                           AS `codon`,
       concat(`a`.`exon`, '号外显子', `a`.`mutation_type`, '(突变丰度:', `a`.`f_freq`, '%)') AS `mutation_result`
from (`omics`.`life_snp_indel_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`                                                                                           AS `file_id`,
       `b`.`platform`                                                                                          AS `platform`,
       `b`.`product_name`                                                                                      AS `product_name`,
       `b`.`analysis_date`                                                                                     AS `analysis_date`,
       `b`.`subbarcode`                                                                                        AS `subbarcode`,
       `a`.`gene`                                                                                              AS `gene`,
       'Amplification'                                                                                         AS `variant`,
       'Amplification'                                                                                         AS `ori_variant`,
       '拷贝数变异'                                                                                            AS `mutation_type`,
       concat(convert(format((`a`.`adjust_cn_value` / 2), 1) using utf8mb4),
              'X')                                                                                             AS `mutFreq`,
       `a`.`report`                                                                                            AS `report`,
       `a`.`filtered_rationale`                                                                                AS `filtered_rationale`,
       `a`.`mapped_variant_id`                                                                                 AS `mapped_variant_id`,
       `a`.`mapped_variant`                                                                                    AS `mapped_variant`,
       ''                                                                                                      AS `exon`,
       ''                                                                                                      AS `codon`,
       concat(`a`.`gene`, '基因拷贝数变异(', convert(format((`a`.`adjust_cn_value` / 2), 1) using utf8),
              'X)')                                                                                            AS `mutation_result`
from (`omics`.`life_cnv_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`                     AS `file_id`,
       `b`.`platform`                    AS `platform`,
       `b`.`product_name`                AS `product_name`,
       `b`.`analysis_date`               AS `analysis_date`,
       `b`.`subbarcode`                  AS `subbarcode`,
       `a`.`gene1`                       AS `gene`,
       `a`.`variant`                     AS `variant`,
       `a`.`ori_variant`                 AS `ori_variant`,
       '融合'                            AS `mutation_type`,
       NULL                              AS `mutFreq`,
       `a`.`report`                      AS `report`,
       `a`.`filtered_rationale`          AS `filtered_rationale`,
       `a`.`mapped_variant_id`           AS `mapped_variant_id`,
       `a`.`mapped_variant`              AS `mapped_variant`,
       ''                                AS `exon`,
       ''                                AS `codon`,
       concat(`a`.`variant`, '融合突变') AS `mutation_result`
from (`omics`.`life_fusion_file` `a` join `omics`.`data_file_status` `b` on ((`b`.`file_id` = `a`.`file_id`)))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'));

