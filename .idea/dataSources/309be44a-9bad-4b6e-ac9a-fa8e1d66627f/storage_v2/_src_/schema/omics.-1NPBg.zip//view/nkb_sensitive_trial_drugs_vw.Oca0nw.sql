create definer = root@localhost view nkb_sensitive_trial_drugs_vw as
select `a`.`gene_variant_id`                                        AS `gene_variant_id`,
       group_concat(distinct `a`.`drug_name_chinese` separator ',') AS `clinical_trial_cancer_drugs`
from `omics`.`nkb_variant_treatment_annotation` `a`
where ((`a`.`relationship_category` = 'Sensitive') and (`a`.`clinical_trial_id` is not null))
group by `a`.`gene_variant_id`;

