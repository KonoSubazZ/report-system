create definer = root@localhost view nkb_clinical_trial_evw as
select `nkb`.`clinical_trial`.`clinical_trial_id`      AS `clinical_trial_id`,
       1                                               AS `lang`,
       `nkb`.`clinical_trial`.`purpose_chinese`        AS `purpose`,
       `nkb`.`clinical_trial`.`title_chinese`          AS `title`,
       `nkb`.`clinical_trial`.`official_title_chinese` AS `official_title`,
       `nkb`.`clinical_trial`.`phase`                  AS `phase`,
       `nkb`.`clinical_trial`.`recruiting_status`      AS `recruiting_status`,
       `nkb`.`clinical_trial`.`condition_chinese`      AS `recruiting_condition`,
       `nkb`.`clinical_trial`.`inclusion_criteria`     AS `inclusion_criteria`,
       `nkb`.`clinical_trial`.`exclusion_criteria`     AS `exclusion_criteria`,
       `nkb`.`clinical_trial`.`location_chinese`       AS `location`,
       `nkb`.`clinical_trial`.`update_date`            AS `update_date`
from `nkb`.`clinical_trial`
union
select `nkb`.`clinical_trial`.`clinical_trial_id`    AS `clinical_trial_id`,
       2                                             AS `lang`,
       `nkb`.`clinical_trial`.`purpose_english`      AS `purpose`,
       `nkb`.`clinical_trial`.`title_english`        AS `title`,
       `nkb`.`clinical_trial`.`official_title`       AS `official_title`,
       `nkb`.`clinical_trial`.`phase`                AS `phase`,
       `nkb`.`clinical_trial`.`recruiting_status`    AS `recruiting_status`,
       `nkb`.`clinical_trial`.`recruiting_condition` AS `recruiting_condition`,
       `nkb`.`clinical_trial`.`inclusion_criteria`   AS `inclusion_criteria`,
       `nkb`.`clinical_trial`.`exclusion_criteria`   AS `exclusion_criteria`,
       `nkb`.`clinical_trial`.`location`             AS `location`,
       `nkb`.`clinical_trial`.`update_date`          AS `update_date`
from `nkb`.`clinical_trial`;

