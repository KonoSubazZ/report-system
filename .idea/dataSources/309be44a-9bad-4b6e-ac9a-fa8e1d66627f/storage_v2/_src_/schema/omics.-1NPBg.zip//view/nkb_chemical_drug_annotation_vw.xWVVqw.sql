create definer = root@localhost view nkb_chemical_drug_annotation_vw as
select distinct `a`.`annotation_id`       AS `annotation_id`,
                `a`.`drug_name`           AS `drug_name`,
                `a`.`drug_name_chinese`   AS `drug_name_chinese`,
                `a`.`drug_type_chinese`   AS `drug_type_chinese`,
                `c`.`gene`                AS `gene`,
                `c`.`rs_id`               AS `rs_id`,
                `c`.`allele`              AS `genotype`,
                `a`.`allele_info`         AS `allele_info`,
                `a`.`annotation_chinese`  AS `annotation_chinese`,
                `a`.`evidence`            AS `evidence`,
                `a`.`annotation_type`     AS `annotation_type`,
                `a`.`toxicity`            AS `toxicity`,
                `a`.`efficacy`            AS `efficacy`,
                `a`.`allele_id`           AS `allele_id`,
                `b`.`cancer_do_id`        AS `cancer_do_id`,
                `b`.`cancer_type_chinese` AS `cancer_type_chinese`
from ((`nkb`.`chemical_drug_annotation` `a` join `nkb`.`allele` `c`
       on ((`c`.`allele_id` = `a`.`allele_id`))) left join `nkb`.`chemical_drug_disease` `b`
      on ((`a`.`annotation_id` = `b`.`annotation_id`)));

