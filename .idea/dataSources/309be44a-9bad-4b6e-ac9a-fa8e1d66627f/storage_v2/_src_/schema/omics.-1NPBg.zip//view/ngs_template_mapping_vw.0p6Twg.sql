create definer = root@localhost view ngs_template_mapping_vw as
select `a`.`mapping_id`    AS `mapping_id`,
       `a`.`product_id`    AS `product_id`,
       `b`.`product_name`  AS `product_name`,
       `b`.`path_name`     AS `path_name`,
       `a`.`template_id`   AS `template_id`,
       `c`.`template_name` AS `template_name`
from ((`omics`.`ngs_template_mapping` `a` join `omics`.`product` `b`
       on ((`a`.`product_id` = `b`.`product_id`))) join `omics`.`pcr_template` `c`
      on ((`a`.`template_id` = `c`.`template_id`)));

