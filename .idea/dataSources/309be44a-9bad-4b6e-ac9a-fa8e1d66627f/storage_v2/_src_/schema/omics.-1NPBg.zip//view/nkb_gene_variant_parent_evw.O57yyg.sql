create definer = novo@`%` view nkb_gene_variant_parent_evw as
select `a`.`gene_variant_id`   AS `gene_variant_id`,
       `a`.`gene_id`           AS `gene_id`,
       `g`.`gene_symbol`       AS `gene_symbol`,
       `a`.`gene_variant`      AS `gene_variant`,
       `b`.`parent_variant_id` AS `parent_variant_id`,
       `c`.`gene_variant`      AS `parent_variant`
from (((`nkb`.`gene_variant` `a` join `nkb`.`ncbi_gene` `g`
        on ((`a`.`gene_id` = `g`.`gene_id`))) join `nkb`.`gene_variant_parent` `b`
       on ((`a`.`gene_variant_id` = `b`.`gene_variant_id`))) join `nkb`.`gene_variant` `c`
      on ((`b`.`parent_variant_id` = `c`.`gene_variant_id`)))
where ((`a`.`checking_status_id` = 2) and (`c`.`checking_status_id` = 2));

