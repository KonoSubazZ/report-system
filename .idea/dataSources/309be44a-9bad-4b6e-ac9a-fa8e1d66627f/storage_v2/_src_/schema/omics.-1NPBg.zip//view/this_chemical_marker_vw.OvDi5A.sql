create definer = root@localhost view this_chemical_marker_vw as
select `a`.`file_id`            AS `file_id`,
       `r`.`report_id`          AS `report_id`,
       `b`.`platform`           AS `platform`,
       `b`.`product_name`       AS `product_name`,
       `b`.`analysis_date`      AS `analysis_date`,
       `b`.`subbarcode`         AS `subbarcode`,
       `a`.`chr`                AS `chr`,
       `a`.`pos`                AS `pos`,
       `a`.`end`                AS `end`,
       `a`.`ref`                AS `ref`,
       `a`.`alt`                AS `alt`,
       `a`.`genotype`           AS `genotype`,
       `a`.`gene`               AS `gene`,
       `a`.`rs_id`              AS `rs_id`,
       `a`.`depth`              AS `depth`,
       `a`.`dp4`                AS `dp4`,
       `a`.`freq`               AS `freq`,
       `a`.`report`             AS `report`,
       `a`.`filtered_rationale` AS `filtered_rationale`,
       `a`.`record_id`          AS `record_id`,
       `a`.`mapped_allele_id`   AS `mapped_allele_id`
from (((`omics`.`chemical_file` `a` join `omics`.`data_file_status` `b`
        on ((`b`.`file_id` = `a`.`file_id`))) join `omics`.`analysis_report` `r`
       on (((`b`.`subbarcode` = `r`.`subbarcode`) and (`b`.`platform` = `r`.`platform`) and
            (`b`.`product_name` = `r`.`product_name`) and
            (`b`.`analysis_date` = `r`.`analysis_date`)))) join `omics`.`panel_gene` `pg`
      on (((`r`.`product_id` = `pg`.`product_id`) and (`a`.`gene` = `pg`.`gene_symbol`) and
           (`pg`.`category` = 'chemical'))))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'))
union
select `a`.`file_id`            AS `file_id`,
       `r`.`report_id`          AS `report_id`,
       `b`.`platform`           AS `platform`,
       `b`.`product_name`       AS `product_name`,
       `b`.`analysis_date`      AS `analysis_date`,
       `b`.`subbarcode`         AS `subbarcode`,
       `a`.`chr`                AS `chr`,
       `a`.`pos`                AS `pos`,
       NULL                     AS `end`,
       `a`.`ref`                AS `ref`,
       `a`.`alt`                AS `alt`,
       `a`.`genotype`           AS `genotype`,
       `a`.`gene`               AS `gene`,
       `a`.`rs`                 AS `rs_id`,
       `a`.`depth`              AS `depth`,
       `a`.`fdp4`               AS `fdp4`,
       `a`.`f_freq`             AS `freq`,
       `a`.`report`             AS `report`,
       `a`.`filtered_rationale` AS `filtered_rationale`,
       `a`.`record_id`          AS `record_id`,
       `a`.`mapped_allele_id`   AS `mapped_allele_id`
from (((`omics`.`life_chemical_file` `a` join `omics`.`data_file_status` `b`
        on ((`b`.`file_id` = `a`.`file_id`))) join `omics`.`analysis_report` `r`
       on (((`b`.`subbarcode` = `r`.`subbarcode`) and (`b`.`platform` = `r`.`platform`) and
            (`b`.`product_name` = `r`.`product_name`) and
            (`b`.`analysis_date` = `r`.`analysis_date`)))) join `omics`.`panel_gene` `pg`
      on (((`r`.`product_id` = `pg`.`product_id`) and (`a`.`gene` = `pg`.`gene_symbol`) and
           (`pg`.`category` = 'chemical'))))
where (isnull(`a`.`report`) or (`a`.`report` <> '0'));

