create definer = root@localhost view pdl1_report_vw as
select `a`.`report_id`        AS `report_id`,
       `a`.`sample_id`        AS `sample_id`,
       `c`.`subbarcode`       AS `subbarcode`,
       `c`.`barcode`          AS `barcode`,
       `a`.`test_id`          AS `test_id`,
       `b`.`platform`         AS `platform`,
       `b`.`category`         AS `category`,
       `b`.`test_name`        AS `test_name`,
       `a`.`tested_date`      AS `tested_date`,
       `a`.`tested_by`        AS `tested_by`,
       `a`.`checked_date`     AS `checked_date`,
       `a`.`checked_by`       AS `checked_by`,
       `a`.`report_date`      AS `report_date`,
       `a`.`report_filename`  AS `report_filename`,
       `a`.`report_file_path` AS `report_file_path`,
       `a`.`created_by`       AS `created_by`,
       `a`.`created_date`     AS `created_date`,
       `a`.`update_by`        AS `update_by`,
       `a`.`update_date`      AS `update_date`
from ((`omics`.`report` `a` join `omics`.`genetic_test` `b`
       on ((`a`.`test_id` = `b`.`test_id`))) join `omics`.`sample_file` `c` on ((`a`.`sample_id` = `c`.`sample_id`)))
where (`b`.`platform` = 'PDL1');

