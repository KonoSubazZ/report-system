create definer = root@localhost view nkb_variant_desc_evw as
select `a`.`annotation_id`            AS `annotation_id`,
       1                              AS `lang`,
       `a`.`gene_variant_id`          AS `gene_variant_id`,
       `g`.`gene_symbol`              AS `gene_symbol`,
       `b`.`gene_variant`             AS `gene_variant`,
       `a`.`description_chinese`      AS `description`,
       `a`.`smple_desc_chinese`       AS `simple_desc`,
       `d`.`variant_evidence_ranking` AS `evidence_ranking`,
       `a`.`update_date`              AS `update_date`
from (((`nkb`.`gene_variant_description` `a` left join `nkb`.`gene_variant` `b`
        on ((`a`.`gene_variant_id` = `b`.`gene_variant_id`))) left join `nkb`.`ncbi_gene` `g`
       on ((`g`.`gene_id` = `b`.`gene_id`))) left join `nkb`.`variant_evidence_ranking` `d`
      on ((`d`.`evidence_ranking_id` = `a`.`evidence_ranking_id`)))
where ((`a`.`annotation_type` = 'onco') and (`a`.`checking_status_id` = 2))
union
select `a`.`annotation_id`            AS `annotation_id`,
       2                              AS `lang`,
       `a`.`gene_variant_id`          AS `gene_variant_id`,
       `g`.`gene_symbol`              AS `gene_symbol`,
       `b`.`gene_variant`             AS `gene_variant`,
       `a`.`description`              AS `description`,
       `a`.`simple_desc`              AS `simple_desc`,
       `d`.`variant_evidence_ranking` AS `evidence_ranking`,
       `a`.`update_date`              AS `update_date`
from (((`nkb`.`gene_variant_description` `a` left join `nkb`.`gene_variant` `b`
        on ((`a`.`gene_variant_id` = `b`.`gene_variant_id`))) left join `nkb`.`ncbi_gene` `g`
       on ((`g`.`gene_id` = `b`.`gene_id`))) left join `nkb`.`variant_evidence_ranking` `d`
      on ((`d`.`evidence_ranking_id` = `a`.`evidence_ranking_id`)))
where ((`a`.`annotation_type` = 'onco') and (`a`.`checking_status_id` = 2));

