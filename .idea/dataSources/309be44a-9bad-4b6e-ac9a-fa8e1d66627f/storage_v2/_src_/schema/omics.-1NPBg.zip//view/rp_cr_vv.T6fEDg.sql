create definer = novo@`%` view rp_cr_vv as
select `omics`.`rp_cr`.`record_id`             AS `record_id`,
       1                                       AS `lang`,
       `omics`.`rp_cr`.`Gene`                  AS `Gene`,
       `omics`.`rp_cr`.`Mutation`              AS `Mutation`,
       `omics`.`rp_cr`.`ori_mutation`          AS `ori_mutation`,
       `omics`.`rp_cr`.`Clinical_significance` AS `Clinical_significance`,
       `omics`.`rp_cr`.`GeneDesc`              AS `GeneDesc`,
       `omics`.`rp_cr`.`VarClianno`            AS `VarClianno`,
       `omics`.`rp_cr`.`has_drug`              AS `has_drug`,
       `omics`.`rp_cr`.`updated_by`            AS `updated_by`,
       `omics`.`rp_cr`.`update_time`           AS `update_time`,
       `omics`.`rp_cr`.`check_date`            AS `check_date`
from `omics`.`rp_cr`;

-- comment on column rp_cr_vv.Clinical_significance not supported: Clinical_significance 字段通常用于表示某个基因变异或突变在临床上的意义。这个字段可能包含以下几种值：
1：表示该变异具有致病性（Pathogenic）。
2：表示该变异可能具有致病性（Likely Pathogenic）。
3：表示该变异的临床意义不确定（Uncertain Significance）。
4：表示该变异可能不具有致病性（Likely Benign）。
5：表示该变异不具有致病性（Benign）。

-- comment on column rp_cr_vv.has_drug not supported: 判断是否有用药 0有、1无

