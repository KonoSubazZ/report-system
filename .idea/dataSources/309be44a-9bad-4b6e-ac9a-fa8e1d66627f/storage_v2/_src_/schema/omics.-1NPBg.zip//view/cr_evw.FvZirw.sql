create definer = novo@`%` view cr_evw as
select `ar`.`report_id`                                                   AS `report_id`,
       `omics`.`cr_all`.`Gene`                                            AS `Gene`,
       `omics`.`cr_all`.`Chr`                                             AS `Chr`,
       `omics`.`cr_all`.`Pos`                                             AS `Pos`,
       `omics`.`cr_all`.`Transcript`                                      AS `Transcript`,
       `omics`.`cr_all`.`Exon`                                            AS `Exon`,
       `omics`.`cr_all`.`cHGVS`                                           AS `cHGVS`,
       `omics`.`cr_all`.`pHGVS`                                           AS `pHGVS`,
       if((`omics`.`cr_all`.`Exon` regexp '^[0-9]+$'),
          concat(`omics`.`cr_all`.`Transcript`, ' ', 'exon', `omics`.`cr_all`.`Exon`, ' ', `omics`.`cr_all`.`cHGVS`,
                 ' ', `omics`.`cr_all`.`pHGVS`),
          concat(`omics`.`cr_all`.`Transcript`, ' ', `omics`.`cr_all`.`Exon`, ' ', `omics`.`cr_all`.`cHGVS`, ' ',
                 `omics`.`cr_all`.`pHGVS`))                               AS `ori_variant`,
       if((`omics`.`cr_all`.`Exon` regexp '^[0-9]+$'), substr(`omics`.`cr_all`.`pHGVS`, 3),
          concat(`omics`.`cr_all`.`Exon`, ' ', `omics`.`cr_all`.`cHGVS`)) AS `variant`,
       `omics`.`cr_all`.`Zygosity`                                        AS `Zygosity`,
       `omics`.`cr_all`.`ExonicFunc`                                      AS `ExonicFunc`,
       `omics`.`cr_all`.`c1000g2015aug_all`                               AS `c1000g2015aug_all`,
       `omics`.`cr_all`.`ExAC_EAS`                                        AS `ExAC_EAS`,
       `omics`.`cr_all`.`avsnp150`                                        AS `avsnp150`,
       `omics`.`cr_all`.`SIFT_pred`                                       AS `SIFT_pred`,
       `omics`.`cr_all`.`Polyphen2_HDIV_pred`                             AS `Polyphen2_HDIV_pred`,
       `omics`.`cr_all`.`MutationTaster_pred`                             AS `MutationTaster_pred`,
       `omics`.`cr_all`.`revel`                                           AS `revel`,
       `omics`.`cr_all`.`gnomAD_genome_ALL`                               AS `gnomAD_genome_ALL`,
       `omics`.`cr_all`.`Interpro_domain`                                 AS `Interpro_domain`,
       `omics`.`cr_all`.`CLNSIG`                                          AS `CLNSIG`,
       `omics`.`cr_all`.`OMIM_Phenotypes`                                 AS `OMIM_Phenotypes`,
       `omics`.`cr_all`.`HGMD_tag`                                        AS `HGMD_tag`,
       `omics`.`cr_all`.`HGMD_disease`                                    AS `HGMD_disease`,
       `omics`.`cr_all`.`HGMD_pmid`                                       AS `HGMD_pmid`,
       `omics`.`cr_all`.`Clinical_significance`                           AS `Clinical_significance`,
       `omics`.`cr_all`.`depth`                                           AS `depth`,
       `omics`.`cr_all`.`loaded_date`                                     AS `loaded_date`,
       `omics`.`cr_all`.`record_id`                                       AS `record_id`,
       `omics`.`cr_all`.`checked_by`                                      AS `checked_by`,
       `omics`.`cr_all`.`checked_date`                                    AS `checked_date`
from (((`omics`.`cr_all` join `omics`.`data_file_status` `da`
        on ((`da`.`file_id` = `omics`.`cr_all`.`file_id`))) join `omics`.`analysis_report` `ar`
       on (((`ar`.`subbarcode` = `da`.`subbarcode`) and (`ar`.`product_name` = `da`.`product_name`) and
            (`ar`.`platform` = `da`.`platform`) and
            (`ar`.`analysis_date` = `da`.`analysis_date`)))) join `omics`.`panel_gene` `pg`
      on (((`ar`.`product_id` = `pg`.`product_id`) and (`omics`.`cr_all`.`Gene` = `pg`.`gene_symbol`) and
           (`pg`.`category` = 'targeted'))))
where (isnull(`omics`.`cr_all`.`report`) or (`omics`.`cr_all`.`report` = 'Y') or (`omics`.`cr_all`.`report` = '1'));

