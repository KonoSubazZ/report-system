create definer = root@localhost view quality_stat_file_vw as
select `a`.`record_id`     AS `record_id`,
       `a`.`file_id`       AS `file_id`,
       `b`.`platform`      AS `platform`,
       `b`.`product_name`  AS `product_name`,
       `a`.`subbarcode`    AS `subbarcode`,
       `b`.`analysis_date` AS `analysis_date`,
       `b`.`data_type`     AS `data_type`,
       `b`.`file_type`     AS `file_type`,
       `a`.`stat_param_id` AS `stat_param_id`,
       `c`.`category`      AS `category`,
       `c`.`param_name`    AS `param_name`,
       `a`.`value`         AS `value`,
       `a`.`loaded_date`   AS `loaded_date`,
       `s`.`sample_type`   AS `sample_type`,
       `s`.`kit`           AS `kit`,
       `s`.`operator1`     AS `operator1`,
       `s`.`value1`        AS `standard_value1`,
       `s`.`operator2`     AS `operator2`,
       `s`.`value2`        AS `standard_value2`
from (((((`omics`.`quality_stat_file` `a` join `omics`.`data_file_status` `b`
          on ((`b`.`file_id` = `a`.`file_id`))) join `omics`.`stat_parameter` `c`
         on ((`c`.`stat_param_id` = `a`.`stat_param_id`))) left join `omics`.`product` `d`
        on ((`b`.`product_name` = `d`.`path_name`))) left join `omics`.`sample_file` `sf`
       on ((`a`.`subbarcode` = `sf`.`subbarcode`))) left join `omics`.`stat_param_standard` `s`
      on (((`s`.`product_id` = `d`.`product_id`) and (`s`.`stat_param_id` = `a`.`stat_param_id`) and
           (`s`.`sample_type` = `sf`.`sample_type`))));

-- comment on column quality_stat_file_vw.sample_type not supported: tissue, blood

