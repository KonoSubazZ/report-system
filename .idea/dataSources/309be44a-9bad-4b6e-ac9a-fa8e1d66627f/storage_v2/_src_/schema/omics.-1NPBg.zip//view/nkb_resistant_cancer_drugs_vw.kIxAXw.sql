create definer = root@localhost view nkb_resistant_cancer_drugs_vw as
select `omics`.`nkb_variant_treatment_annotation`.`gene_variant_id`                                        AS `gene_variant_id`,
       group_concat(distinct `omics`.`nkb_variant_treatment_annotation`.`drug_name_chinese` separator
                    ',')                                                                                   AS `resistant_cancer_drugs`
from `omics`.`nkb_variant_treatment_annotation`
where (`omics`.`nkb_variant_treatment_annotation`.`relationship_category` = 'Resistance')
group by `omics`.`nkb_variant_treatment_annotation`.`gene_variant_id`;

