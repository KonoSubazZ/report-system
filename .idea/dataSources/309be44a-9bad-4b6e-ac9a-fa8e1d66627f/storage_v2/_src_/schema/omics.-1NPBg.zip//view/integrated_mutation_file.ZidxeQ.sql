create definer = root@localhost view integrated_mutation_file as
select distinct `a`.`file_id`                     AS `file_id`,
                `a`.`file_path`                   AS `file_path`,
                `a`.`file_name`                   AS `file_name`,
                `a`.`data_type`                   AS `data_type`,
                `a`.`file_type`                   AS `file_type`,
                `a`.`analysis_date`               AS `analysis_date`,
                `a`.`barcode`                     AS `barcode`,
                `a`.`subbarcode`                  AS `subbarcode`,
                `b`.`person_name`                 AS `person_name`,
                `a`.`product_name`                AS `path_name`,
                `b`.`product_name`                AS `product_name`,
                `a`.`platform`                    AS `platform`,
                `b`.`received_date`               AS `received_date`,
                `b`.`hospital`                    AS `hospital`,
                `b`.`specimen_type`               AS `specimen_type`,
                `b`.`clinicalremark`              AS `clinicalremark`,
                `b`.`cancertype`                  AS `cancertype`,
                `b`.`pathologicaltype`            AS `pathologicaltype`,
                `c`.`gene`                        AS `gene`,
                `c`.`mutation`                    AS `mutation`,
                `c`.`variant`                     AS `variant`,
                `c`.`mutation_frequency`          AS `mutation_frequency`,
                `c`.`other_info`                  AS `other_info`,
                `c`.`drugs_for_indication`        AS `drugs_for_indication`,
                `c`.`drugs_for_other_indications` AS `drugs_for_other_indications`,
                `c`.`drugs_in_clinical_trials`    AS `drugs_in_clinical_trials`,
                `c`.`drug_resistance_info`        AS `drug_resistance_info`,
                `c`.`resistance_desc`             AS `resistance_desc`,
                `b`.`fastcode`                    AS `fastcode`
from ((`omics`.`data_file_status` `a` left join `omics`.`sample_file` `b`
       on ((`a`.`subbarcode` = `b`.`subbarcode`))) join `omics`.`mutation_file` `c`
      on ((`a`.`file_id` = `c`.`file_id`)))
where ((`a`.`data_type` = 'mutation') and (`a`.`status` = 'Loaded'));

-- comment on column integrated_mutation_file.barcode not supported: patient id

-- comment on column integrated_mutation_file.subbarcode not supported: speciment id

-- comment on column integrated_mutation_file.clinicalremark not supported: 临床备注

-- comment on column integrated_mutation_file.cancertype not supported: 检测癌种

-- comment on column integrated_mutation_file.mutation_frequency not supported: %

