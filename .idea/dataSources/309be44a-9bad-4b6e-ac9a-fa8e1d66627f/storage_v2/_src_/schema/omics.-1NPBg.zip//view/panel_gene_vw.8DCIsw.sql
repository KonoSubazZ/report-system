create definer = root@localhost view panel_gene_vw as
select `a`.`product_id`           AS `product_id`,
       `b`.`product_name_chinese` AS `product_name_chinese`,
       `b`.`path_name`            AS `path_name`,
       `b`.`path_name`            AS `product_name`,
       `a`.`gene`                 AS `gene`,
       `a`.`gene_id`              AS `gene_id`,
       `a`.`gene_symbol`          AS `gene_symbol`,
       `a`.`category`             AS `category`,
       `a`.`mutation_type`        AS `mutation_type`
from (`omics`.`panel_gene` `a` join `omics`.`product` `b` on ((`a`.`product_id` = `b`.`product_id`)));

-- comment on column panel_gene_vw.category not supported: targeted, chemical 【必填】和胚体系位点检出有关
targeted 的基因才会检出

